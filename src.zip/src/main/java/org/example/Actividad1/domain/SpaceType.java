package org.example.Actividad1.domain;

public enum SpaceType { HABITACION, ESCRITORIO, OFICINA }
