package org.example.Actividad1.domain;

public enum BookingStatus { PENDIENTE, CONFIRMADO, CANCELADO }
