package org.example.Actividad1.dao;

import org.example.Actividad1.domain.Booking;

public interface BookingDao extends GenericDao<Booking, Long> {
}
