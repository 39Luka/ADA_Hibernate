package org.example.Actividad1.dao;

import org.example.Actividad1.domain.Tag;

public interface TagDao extends GenericDao<Tag, Long> {
}
