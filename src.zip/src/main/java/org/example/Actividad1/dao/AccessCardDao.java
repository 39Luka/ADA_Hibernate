package org.example.Actividad1.dao;

import org.example.Actividad1.domain.AccessCard;

public interface AccessCardDao extends GenericDao<AccessCard,Long> {
}
