package org.example.Actividad1.dao;

import org.example.Actividad1.domain.Venue;

public interface VenueDao extends GenericDao<Venue, Long> {
}
