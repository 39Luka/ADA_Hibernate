package org.example.Actividad1.dao;

import org.example.Actividad1.domain.User;

public interface UserDao extends GenericDao<User, Long> {

}
