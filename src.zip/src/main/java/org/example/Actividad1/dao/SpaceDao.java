package org.example.Actividad1.dao;

import org.example.Actividad1.domain.Space;

public interface SpaceDao extends GenericDao<Space, Long> {
}
