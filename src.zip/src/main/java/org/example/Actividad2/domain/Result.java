package org.example.Actividad2.domain;

public enum Result {WIN, LOSE, DRAW}
