package org.example.Actividad2.domain;

public enum Status {ACTIVE, MAINTENANCE, RETIRED}
