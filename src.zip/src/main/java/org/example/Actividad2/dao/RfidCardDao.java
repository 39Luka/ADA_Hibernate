package org.example.Actividad2.dao;

import org.example.Actividad2.domain.RfidCard;

public interface RfidCardDao extends GenericDao<RfidCard, Long>{
}
