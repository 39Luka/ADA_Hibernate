package org.example.Actividad2.dao;

import org.example.Actividad2.domain.Match;

public interface MatchDao extends GenericDao<Match,Long>{
}
