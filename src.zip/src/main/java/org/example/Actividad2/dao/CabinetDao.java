package org.example.Actividad2.dao;

import org.example.Actividad2.domain.Cabinet;

public interface CabinetDao extends GenericDao<Cabinet,Long> {
}
