package org.example.Actividad2.dao;

import org.example.Actividad2.domain.Player;

public interface PlayerDao extends GenericDao<Player,Long> {
}
