package org.example.Actividad2.dao;

import org.example.Actividad2.domain.Arcade;

public interface ArcadeDao extends GenericDao<Arcade,Long> {
}
