package org.example.Actividad2.dao;

import org.example.Actividad2.domain.Game;

public interface GameDao extends GenericDao<Game,Long>{
}
