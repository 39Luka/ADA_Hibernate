package org.example.Actividad2.dao;

import org.example.Actividad2.domain.Tag;

public interface TagDao extends GenericDao<Tag,Long>{
}
